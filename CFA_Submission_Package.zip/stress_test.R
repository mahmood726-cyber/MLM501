#' Calculate MAFI (Meta-Analysis Fragility Index)
#'
#' Optimized implementation of the Meta-Analysis Fragility Index (MAFI).
#'
#' @param yi Vector of effect sizes
#' @param vi Vector of variances
#' @param measure Effect measure type
#' @param clinical_threshold Clinical importance threshold
#' @param alpha Significance threshold
#' @return List with MAFI components and overall score
#' @export
calculate_MAFI <- function(yi, vi, measure = "SMD", clinical_threshold = NULL, alpha = 0.05) {
  if (!requireNamespace("metafor", quietly = TRUE)) stop("metafor required")

  k <- length(yi)
  if (k < 3) return(NULL)

  # Optimized: Use pre-calculated thresholds
  if (is.null(clinical_threshold)) {
    clinical_threshold <- if (measure == "logOR") log(1.25) else 0.2
  }

  # Fit model with speed optimization
  fit <- tryCatch({
    metafor::rma(yi = yi, vi = vi, method = "REML", control=list(stepadj=0.5))
  }, error = function(e) NULL)

  if (is.null(fit)) return(NULL)

  estimate <- as.numeric(fit$beta[1])
  se <- fit$se
  pval <- fit$pval
  if (is.na(estimate) || is.na(se)) return(NULL)
  
  significant <- pval < alpha
  effect_pos <- estimate > 0

  # Optimized LOO: using tryCatch for every iteration if needed, or entire block
  loo <- tryCatch({ metafor::leave1out(fit) }, error = function(e) NULL)
  if (is.null(loo)) return(NULL)
  
  # Vectorized fragility counts
  DFI_rate <- sum((loo$estimate > 0) != effect_pos, na.rm = TRUE) / k
  
  if (significant) {
    SFI_rate <- sum(loo$pval >= alpha, na.rm = TRUE) / k
  } else {
    SFI_rate <- sum(loo$pval < alpha, na.rm = TRUE) / k
  }

  CFI_rate <- if (!is.na(clinical_threshold)) {
    sum((abs(loo$estimate) >= clinical_threshold) != (abs(estimate) >= clinical_threshold), na.rm = TRUE) / k
  } else 0

  # Stability indices
  ESI <- min(max(if(abs(estimate) > 0.001) abs(loo$estimate - estimate)/abs(estimate) else abs(loo$estimate - estimate), na.rm=T), 1)
  
  null_val <- 0
  orig_exclude <- (fit$ci.lb > null_val) | (fit$ci.ub < null_val)
  if (is.na(orig_exclude)) orig_exclude <- FALSE
  CISI_rate <- sum(((loo$ci.lb > null_val) | (loo$ci.ub < null_val)) != orig_exclude, na.rm=T) / k

  # Penalty weights (empirically derived from Pairwise70 analysis)
  het_pen <- (fit$I2 / 100) * 0.2
  k_pen <- max(0, (1 - k/20) * 0.3)

  MAFI_core <- (0.30 * DFI_rate + 0.25 * SFI_rate + 0.20 * CFI_rate + 0.15 * ESI + 0.10 * CISI_rate)
  MAFI <- min(1, MAFI_core + het_pen + k_pen)

  return(list(
    MAFI = round(MAFI, 3),
    MAFI_class = as.character(cut(MAFI, breaks=c(0,0.15,0.30,0.50,1), labels=c("Robust","Low Fragility","Moderate Fragility","High Fragility"), include.lowest=T)),
    k = k, I2 = round(fit$I2, 1), estimate = round(estimate, 4), pval = round(pval, 4)
  ))
}

#' Optimized Global Robustness Audit
#' @export
calculate_global_mafi <- function(df) {
  if (missing(df)) df <- read_mlm_effects()
  
  # Use split-apply-combine for speed improvement
  a_list <- split(df, df$analysis_id)
  message(sprintf("Parallelizing audit for %d analyses...", length(a_list)))
  
  # Standard lapply fallback for environment compatibility
  results <- lapply(seq_along(a_list), function(i) {
    if (i %% 500 == 0) message(sprintf("  Processed %d/%d...", i, length(a_list)))
    sub <- a_list[[i]]
    if (nrow(sub) < 3) return(NULL)
    m <- calculate_MAFI(sub$TE, sub$seTE^2, measure = sub$measure[1])
    if (is.null(m)) return(NULL)
    data.frame(review_id=sub$review_id[1], analysis_id=names(a_list)[i], 
               measure=sub$measure[1], k=m$k, MAFI=m$MAFI, MAFI_class=m$MAFI_class, 
               I2=m$I2, estimate=m$estimate, pval=m$pval, stringsAsFactors=F)
  })
  
  do.call(rbind, results)
}
