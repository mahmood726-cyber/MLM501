#' Evidence Pathway Engine: Test -> Treat Simulation
#'
#' This module integrates Diagnostic Test Accuracy (DTA) with Treatment Effects (TE)
#' to calculate the Net Clinical Benefit (NCB) of an entire clinical pathway.
#'
#' @param prevalence Disease prevalence in the population (0-1)
#' @param sensitivity Diagnostic test sensitivity (0-1)
#' @param specificity Diagnostic test specificity (0-1)
#' @param rr Treatment relative risk (e.g., from Cochrane MLM table)
#' @param harm_rate Rate of harm/adverse events from treatment (0-1)
#' @param n Population size for simulation (default: 1000)
#' @return List with pathway outcomes and Net Clinical Benefit
#' @export
simulate_pathway <- function(prevalence, sensitivity, specificity, rr, harm_rate = 0, n = 1000) {
  
  # 1. Diagnostic Phase
  tp <- n * prevalence * sensitivity
  fn <- n * prevalence * (1 - sensitivity)
  fp <- n * (1 - prevalence) * (1 - specificity)
  tn <- n * (1 - prevalence) * specificity
  
  treated <- tp + fp
  not_treated <- fn + tn
  
  # 2. Treatment Phase
  # Base risk for TP is 1 (they have disease), but we use prevalence as base risk group
  # Events in Treated (TP)
  events_tp_base <- tp
  events_tp_treated <- tp * rr
  events_prevented <- events_tp_base - events_tp_treated
  
  # Harms in all treated (TP + FP)
  total_harms <- treated * harm_rate
  
  # 3. Net Clinical Benefit
  # NCB = Benefits - Harms - Missed Cases
  # Here we use a simple additive model, but weights could be added
  ncb <- events_prevented - total_harms
  
  return(list(
    population = n,
    prevalence = prevalence,
    test_performance = list(tp = tp, fp = fp, fn = fn, tn = tn),
    treated = treated,
    events_prevented = round(events_prevented, 2),
    total_harms = round(total_harms, 2),
    net_benefit = round(ncb, 2),
    benefit_per_1000 = round((ncb / n) * 1000, 2)
  ))
}

#' Plot the Pathway Benefit Frontier
#'
#' Visualizes how the Net Clinical Benefit changes with varying diagnostic sensitivity.
#'
#' @param prevalence Disease prevalence
#' @param specificity Diagnostic specificity
#' @param rr Treatment relative risk
#' @param harm_rate Harm rate
#' @export
plot_pathway_frontier <- function(prevalence, specificity, rr, harm_rate = 0.01) {
  if (!requireNamespace("ggplot2", quietly = TRUE)) stop("ggplot2 required")
  
  sens_range <- seq(0.5, 1, by = 0.01)
  results <- sapply(sens_range, function(s) {
    simulate_pathway(prevalence, s, specificity, rr, harm_rate)$net_benefit
  })
  
  df_plot <- data.frame(Sensitivity = sens_range, NetBenefit = results)
  
  ggplot2::ggplot(df_plot, ggplot2::aes(x = Sensitivity, y = NetBenefit)) +
    ggplot2::geom_line(color = "#3498db", size = 1.2) +
    ggplot2::geom_area(fill = "#3498db", alpha = 0.1) +
    ggplot2::labs(title = "Clinical Pathway Frontier",
                  subtitle = sprintf("Net Benefit vs. Sensitivity (Prev: %.1f, Spec: %.1f, RR: %.2f)", 
                                     prevalence, specificity, rr),
                  x = "Test Sensitivity", y = "Net Clinical Benefit (per 1000)") +
    ggplot2::theme_minimal()
}
