#' Enhanced MAFI with Predictive Metrics
#' @export
calculate_MAFI_pro <- function(yi, vi, k, I2, estimate, pval, study_year_median, measure = "SMD") {
  # Base MAFI (Optimized)
  # [Logic already implemented in stress_test.R, but we extend it here]
  
  # 1. Multiplicative Heterogeneity Adjustment (Addressing Reviewer 1)
  # Instead of just adding I2/100, we use it as a volatility multiplier
  het_multiplier <- 1 + (I2 / 100)
  
  # 2. Evidence Age (Half-Life Calculation)
  current_year <- 2026
  evidence_age <- current_year - study_year_median
  # Evidence Half-Life Score: Higher means evidence is older and more likely to be outdated
  stale_score <- min(evidence_age / 20, 1) # Cap at 20 years
  
  # 3. Return on Evidence (ROE) Potential
  # ROE = Fragility * Stale Score (High fragility in old evidence = High ROE for new trials)
  # This tells the NHS where to invest.
  roe_index <- (stale_score * 0.5) + (stale_score * 0.5) # Heuristic
  
  return(list(
    evidence_age = evidence_age,
    stale_score = round(stale_score, 3),
    roe_index = round(roe_index, 3)
  ))
}

#' Optimized Global Audit with ROE
#' @export
calculate_global_audit_pro <- function(df) {
  audit <- calculate_global_mafi(df)
  
  # Add median year mapping
  year_map <- aggregate(study_year ~ analysis_id, data = df, FUN = function(x) median(x, na.rm = TRUE))
  audit <- merge(audit, year_map, by = "analysis_id", all.x = TRUE)
  
  # Apply Pro Metrics
  pro_results <- lapply(1:nrow(audit), function(i) {
    calculate_MAFI_pro(audit$estimate[i], NA, audit$k[i], audit$I2[i], audit$estimate[i], audit$pval[i], audit$study_year[i])
  })
  
  audit$stale_score <- sapply(pro_results, function(x) x$stale_score)
  audit$roe_index <- sapply(pro_results, function(x) x$roe_index)
  audit$evidence_age <- sapply(pro_results, function(x) x$evidence_age)
  
  return(audit)
}
