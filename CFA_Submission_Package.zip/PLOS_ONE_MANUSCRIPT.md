# RESEARCH ARTICLE
# Mapping the Stability of Global Medical Evidence: A Comprehensive Fragility Audit of 2,373 Cochrane Meta-Analyses

**Authors:** Mahmood Ahmad, et al.
**Affiliation:** NHS Research Synthesis Methods / Cochrane Collaboration
**Target Journal:** PLOS ONE

---

## Abstract
**Background:** Systematic reviews and meta-analyses are considered the highest level of clinical evidence. However, the robustness of these conclusions to the exclusion of individual studies remains poorly quantified at scale.
**Methods:** We developed the Cochrane Fragility Atlas (CFA), an automated evidence audit engine. Using a multilevel effects table derived from 501 Cochrane reviews (2,373 analyses), we applied the Meta-Analysis Fragility Index (MAFI)—a 5-component stress test measuring stability in direction, significance, clinical threshold, effect magnitude, and confidence intervals. We further integrated an Evidence Pathway Engine to simulate the real-world impact of findings through "Test-Treat" pathways.
**Results:** Of the 2,373 analyses audited, 17% (n=400) were classified as 'Robust' (stable anchors), while 12% (n=288) exhibited 'High Fragility' (the Evidence Frontier), where conclusions were susceptible to being overturned by a single study change. logOR measures showed higher inherent fragility (0.347) compared to GIV (0.263). Temporal analysis indicates a stabilizing trend in evidence robustness over the last two decades.
**Conclusions:** A significant portion of the global evidence base is highly fragile. The CFA provides a real-time audit tool for guideline developers to identify "at-risk" clinical recommendations and prioritize research areas where new trials will yield the highest "Return on Evidence."

---

## 1. Introduction
The "replication crisis" in medicine has highlighted the need for tools that quantify the stability of clinical conclusions. Traditional metrics like the Fragility Index (FI) are often limited to dichotomous outcomes and do not account for heterogeneity or clinical importance. We present the MAFI as a multi-dimensional alternative and apply it at a global scale.

## 2. Methods
### 2.1 The Multilevel Effects Database
Data were extracted from 501 Cochrane pairwise reviews, capturing TE, seTE, and moderators.
### 2.2 The MAFI Formula
MAFI = (0.30 × Direction) + (0.25 × Significance) + (0.20 × Clinical) + (0.15 × Effect Stability) + (0.10 × CI Stability) + Heterogeneity/Sample Size Penalties.
### 2.3 The Evidence Pathway Engine
A simulation model was developed to translate MAFI scores into Net Clinical Benefit (NCB) using the formula: NCB = (True Positives × RR) - (Total Treated × Harm Rate).

## 3. Results
The global audit identified a "Fragility Frontier" in specific clinical domains. [Insert Figure 1: The Cochrane Entropy Landscape]. 12% of meta-analyses were found to be highly fragile, suggesting a need for urgent research verification in these areas.

## 4. Discussion
The integration of MAFI with GRADE imprecision assessments allows for automated evidence downgrading. The Pathway Engine demonstrates that even "statistically significant" results can lead to negative net benefit if the diagnostic test is fragile or treatment harms are high.

## 5. Conclusion
The Cochrane Fragility Atlas represents a paradigm shift from "What do we know?" to "How stable is our knowledge?" This tool is essential for the future of evidence-based policy and research prioritization.

---
**Data Availability:** All audit data and code are available in the MLM501 R package repository.
**Funding:** Supported by [NHS Grant/Internal].
